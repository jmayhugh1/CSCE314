Problem 2:

ImprovedFibonacci was modified and improved in the class SubsetOutputFib. To run this first compile Fibonacci.java by typing in: javac Fibonacci.java,
then run java SubsetOutputFib. This will ask for a number to begin and end the seqence at and will print out all the numbers up to that value. This will also put a star by the 
even numbers. It also handles the errors specified by the hw4.pdf

Problem 3:

type in java ImprovedFibonacci to run this one. it modifies the ImprovedFibonacci application to store its sequence in an array. 
It creates a new class to hold both the value and a boolean value that says whether the value is even, and then having an array of object references to objects of that class.
My code specifically prints out the first 9 values. 

Problem 4: Fields for speed, direction, owner, and two vehicle ID fields were added. I made 3 constructors one has no arguments, one has 1 argument, and one has 3 arguments.


Problem 5: This can be run by compiling with javac Vehicle.java and then running java VehicleTest to see 
In the vehicle test main method the first ten vehicles are created and printed, the first 5 are done using the no-arg constructor and the last 5 are done using the 1-arg constructor.
They are printed out and the first 5 lines in the output show this functionality. The static method that returns the highest ID is called and the output is shown.

Problem 6: This can be run by compiling with javac Vehicle.java and then running java VehicleTest to see the functionality. This toString's functionality can be seen in the output where every vehicle is printed out using the toString
method. 

Problem 7: This can be run by compiling with javac Vehicle.java and then running java VehicleTest to see the output. Its output should appear in the terminal under testing the change speed and stop method. You can see the differences in speed by looking at the previous outputs.


Problem 8: This is ran the same way as the previous problems. The functionality for this is shown under "Testing the turn method" the last two test are using the constants turnLeft and turnRight.

Problem 9: this is run by first compiling the Vehicle.java file and then running java PassengerVehicle. When this file is run it constructs 5 cars then stores them in an ArrayList. Then it test the functionality of the addPassenger function. 
It then iterates through and uses the new toString to print them out.
But before they are printed out the ArrayList is sorted using the sort function and the compare to. The sort function is a modified version of the one in the book. It uses the compareTo method to compare the number of passengers in each car.